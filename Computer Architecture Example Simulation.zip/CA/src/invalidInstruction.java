
public class invalidInstruction extends Exception {
	
	public invalidInstruction(String errorMessage) {
        super(errorMessage);
    }
	
	public invalidInstruction() {
        super();
    }

}
